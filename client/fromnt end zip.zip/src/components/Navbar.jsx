import { useState } from 'react';
import { AppBar, Toolbar, Typography, Button, Box, Menu, MenuItem, Avatar, IconButton } from '@mui/material';
import { Link } from 'react-router-dom';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import CollectionsIcon from '@mui/icons-material/Collections';
import BrushIcon from '@mui/icons-material/Brush';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import FolderIcon from '@mui/icons-material/Folder';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import Brightness4Icon from '@mui/icons-material/Brightness4';
import Brightness7Icon from '@mui/icons-material/Brightness7';
import { useAuth } from '../context/AuthContext';
import Login from './Login';
import Register from './Register';

function Navbar({ toggleTheme, mode }) {
  const { user, logout } = useAuth();
  const [anchorEl, setAnchorEl] = useState(null);
  const [loginOpen, setLoginOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);

  const handleMenu = (event) => setAnchorEl(event.currentTarget);
  const handleClose = () => setAnchorEl(null);

  const handleLogout = () => {
    logout();
    handleClose();
  };

  return (
    <>
      <AppBar 
        position="sticky" 
        elevation={0}
        sx={{ 
          background: 'rgba(15, 15, 35, 0.8)', 
          backdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(168, 85, 247, 0.2)',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: '1px',
            background: 'linear-gradient(90deg, transparent, rgba(168, 85, 247, 0.5), transparent)'
          }
        }}
      >
        <Toolbar sx={{ py: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
            <BrushIcon sx={{ mr: 1.5, color: '#ec4899', fontSize: 28 }} />
            <Typography 
              variant="h5" 
              sx={{ 
                fontWeight: 800, 
                letterSpacing: '-0.02em',
                background: 'linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #f59e0b 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent'
              }}
            >
              AI Art Studio
            </Typography>
          </Box>
          
          <Box sx={{ flexGrow: 1 }} />
          
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <IconButton 
              onClick={toggleTheme} 
              color="inherit"
              sx={{
                transition: 'all 0.3s ease',
                '&:hover': {
                  background: 'rgba(168, 85, 247, 0.1)',
                  transform: 'rotate(180deg)'
                }
              }}
            >
              {mode === 'dark' ? <Brightness7Icon /> : <Brightness4Icon />}
            </IconButton>
            <Button 
              color="inherit" 
              component={Link} 
              to="/" 
              startIcon={<AutoAwesomeIcon />}
              sx={{
                borderRadius: 2,
                px: 2,
                py: 1,
                fontWeight: 600,
                transition: 'all 0.3s ease',
                '&:hover': {
                  background: 'rgba(168, 85, 247, 0.1)',
                  transform: 'translateY(-1px)'
                }
              }}
            >
              Create
            </Button>
            <Button 
              color="inherit" 
              component={Link} 
              to="/gallery" 
              startIcon={<CollectionsIcon />}
              sx={{
                borderRadius: 2,
                px: 2,
                py: 1,
                fontWeight: 600,
                transition: 'all 0.3s ease',
                '&:hover': {
                  background: 'rgba(168, 85, 247, 0.1)',
                  transform: 'translateY(-1px)'
                }
              }}
            >
              Gallery
            </Button>
            
            {user ? (
              <>
                <Button 
                  color="inherit" 
                  component={Link} 
                  to="/my-collection" 
                  startIcon={<FolderIcon />}
                  sx={{
                    borderRadius: 2,
                    px: 2,
                    py: 1,
                    fontWeight: 600,
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      background: 'rgba(168, 85, 247, 0.1)',
                      transform: 'translateY(-1px)'
                    }
                  }}
                >
                  My Art
                </Button>
                {user.role === 'admin' && (
                  <Button 
                    color="inherit" 
                    component={Link} 
                    to="/admin" 
                    startIcon={<AdminPanelSettingsIcon />}
                    sx={{
                      borderRadius: 2,
                      px: 2,
                      py: 1,
                      fontWeight: 600,
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        background: 'rgba(168, 85, 247, 0.1)',
                        transform: 'translateY(-1px)'
                      }
                    }}
                  >
                    Admin
                  </Button>
                )}
                <IconButton 
                  onClick={handleMenu} 
                  sx={{ 
                    ml: 2,
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'scale(1.1)'
                    }
                  }}
                >
                  <Avatar 
                    sx={{ 
                      width: 36, 
                      height: 36, 
                      background: 'linear-gradient(135deg, #a855f7 0%, #ec4899 100%)',
                      fontWeight: 700,
                      border: '2px solid rgba(168, 85, 247, 0.3)'
                    }}
                  >
                    {user.username[0].toUpperCase()}
                  </Avatar>
                </IconButton>
                <Menu 
                  anchorEl={anchorEl} 
                  open={Boolean(anchorEl)} 
                  onClose={handleClose}
                  PaperProps={{
                    sx: {
                      background: mode === 'dark' ? '#1e1b4b' : '#ffffff',
                      border: '1px solid rgba(168, 85, 247, 0.2)',
                      borderRadius: 3,
                      mt: 1,
                      boxShadow: mode === 'light' ? '0 4px 20px rgba(0, 0, 0, 0.15)' : 'none'
                    }
                  }}
                >
                  <MenuItem 
                    onClick={handleClose}
                    sx={{
                      py: 1.5,
                      px: 3,
                      '&:hover': {
                        background: 'rgba(168, 85, 247, 0.1)'
                      }
                    }}
                  >
                    <AccountCircleIcon sx={{ mr: 2, color: '#a855f7' }} /> 
                    <Box>
                      <Typography variant="body1" fontWeight={600}>{user.username}</Typography>
                      <Typography variant="caption" color="text.secondary">Profile</Typography>
                    </Box>
                  </MenuItem>
                  <MenuItem 
                    onClick={handleLogout}
                    sx={{
                      py: 1.5,
                      px: 3,
                      color: '#ef4444',
                      '&:hover': {
                        background: 'rgba(239, 68, 68, 0.1)'
                      }
                    }}
                  >
                    Logout
                  </MenuItem>
                </Menu>
              </>
            ) : (
              <>
                <Button 
                  color="inherit" 
                  onClick={() => setLoginOpen(true)}
                  sx={{
                    borderRadius: 2,
                    px: 3,
                    py: 1,
                    fontWeight: 600,
                    border: '1px solid rgba(168, 85, 247, 0.3)',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      background: 'rgba(168, 85, 247, 0.1)',
                      borderColor: 'rgba(168, 85, 247, 0.5)',
                      transform: 'translateY(-1px)'
                    }
                  }}
                >
                  Login
                </Button>
                <Button 
                  onClick={() => setRegisterOpen(true)}
                  sx={{
                    borderRadius: 2,
                    px: 3,
                    py: 1,
                    ml: 1,
                    fontWeight: 600,
                    background: 'linear-gradient(135deg, #a855f7 0%, #ec4899 100%)',
                    color: 'white',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      background: 'linear-gradient(135deg, #9333ea 0%, #db2777 100%)',
                      transform: 'translateY(-1px)',
                      boxShadow: '0 4px 15px rgba(168, 85, 247, 0.4)'
                    }
                  }}
                >
                  Sign Up
                </Button>
              </>
            )}
          </Box>
        </Toolbar>
      </AppBar>
      
      <Login 
        open={loginOpen} 
        onClose={() => setLoginOpen(false)}
        switchToRegister={() => { setLoginOpen(false); setRegisterOpen(true); }}
      />
      <Register 
        open={registerOpen} 
        onClose={() => setRegisterOpen(false)}
        switchToLogin={() => { setRegisterOpen(false); setLoginOpen(true); }}
      />
    </>
  );
}

export default Navbar;
