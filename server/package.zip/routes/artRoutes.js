const express = require('express');
const router = express.Router();
const Art = require('../models/Art');
const { auth, adminAuth } = require('../middleware/auth');
const axios = require('axios');

const styles = {
  'van-gogh': 'in the style of Van Gogh with swirling brushstrokes',
  'watercolor': 'watercolor painting style with soft flowing colors',
  'cyberpunk': 'cyberpunk futuristic neon style',
  'anime': 'anime manga art style',
  'realistic': 'photorealistic detailed style'
};

// Simple AI image generation using Pollinations
const generateImage = (enhancedPrompt) => {
  const encodedPrompt = encodeURIComponent(enhancedPrompt);
  return `https://image.pollinations.ai/prompt/${encodedPrompt}?width=512&height=512&nologo=true&enhance=true&seed=${Math.floor(Math.random() * 10000)}`;
};

// Generate AI Art
router.post('/generate', auth, async (req, res) => {
  try {
    const { prompt, style = 'default' } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    // Apply style to prompt
    let enhancedPrompt = prompt;
    if (style !== 'default' && styles[style]) {
      enhancedPrompt = `${prompt}, ${styles[style]}`;
    }

    const imageUrl = generateImage(enhancedPrompt);
    res.json({ imageUrl, enhancedPrompt });
  } catch (error) {
    console.error('Generation error:', error.message);
    res.status(500).json({ error: 'Failed to generate image' });
  }
});

// Save art to gallery
router.post('/save', auth, async (req, res) => {
  try {
    const { title, prompt, imageUrl, style = 'default', tags = [], isPublic = true } = req.body;
    const art = new Art({ 
      title,
      prompt, 
      imageUrl, 
      user: req.user._id, 
      style, 
      tags,
      isPublic 
    });
    await art.save();
    await art.populate('user', 'username avatar');
    res.json(art);
  } catch (error) {
    res.status(500).json({ error: 'Failed to save art' });
  }
});

// Get all gallery art
router.get('/gallery', async (req, res) => {
  try {
    const arts = await Art.find({ isPublic: true })
      .populate('user', 'username avatar')
      .populate('comments.user', 'username avatar')
      .sort({ createdAt: -1 });
    res.json(arts);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch gallery' });
  }
});

// Get user's collection
router.get('/my-collection', auth, async (req, res) => {
  try {
    console.log('Fetching collection for user:', req.user._id);
    const arts = await Art.find({ user: req.user._id })
      .populate('user', 'username avatar')
      .sort({ createdAt: -1 });
    console.log('Found arts:', arts.length);
    res.json(arts);
  } catch (error) {
    console.error('Collection fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch collection' });
  }
});

// Like/Unlike art
router.patch('/:id/like', auth, async (req, res) => {
  try {
    const art = await Art.findById(req.params.id);
    const isLiked = art.likes.includes(req.user._id);
    
    if (isLiked) {
      art.likes.pull(req.user._id);
    } else {
      art.likes.push(req.user._id);
    }
    
    await art.save();
    await art.populate('user', 'username avatar');
    res.json(art);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update like' });
  }
});

// Add comment (one per user)
router.post('/:id/comment', auth, async (req, res) => {
  try {
    const { comment, text } = req.body;
    const commentText = comment || text;
    
    if (!commentText || !commentText.trim()) {
      return res.status(400).json({ error: 'Comment text is required' });
    }
    
    const art = await Art.findById(req.params.id);
    if (!art) {
      return res.status(404).json({ error: 'Art not found' });
    }
    
    // Check if user already commented
    const existingCommentIndex = art.comments.findIndex(
      c => c.user.toString() === req.user._id.toString()
    );
    
    if (existingCommentIndex !== -1) {
      return res.status(400).json({ error: 'You have already commented on this artwork' });
    }
    
    art.comments.push({ user: req.user._id, text: commentText.trim() });
    await art.save();
    await art.populate('comments.user', 'username avatar');
    
    res.json({ comments: art.comments });
  } catch (error) {
    console.error('Comment error:', error);
    res.status(500).json({ error: 'Failed to add comment' });
  }
});

// Edit comment
router.patch('/:id/comment/:commentId', auth, async (req, res) => {
  try {
    const { text } = req.body;
    
    if (!text || !text.trim()) {
      return res.status(400).json({ error: 'Comment text is required' });
    }
    
    const art = await Art.findById(req.params.id);
    if (!art) {
      return res.status(404).json({ error: 'Art not found' });
    }
    
    const comment = art.comments.id(req.params.commentId);
    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }
    
    if (comment.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Unauthorized' });
    }
    
    comment.text = text.trim();
    await art.save();
    await art.populate('comments.user', 'username avatar');
    
    res.json({ comments: art.comments });
  } catch (error) {
    console.error('Edit comment error:', error);
    res.status(500).json({ error: 'Failed to edit comment' });
  }
});

// Delete comment
router.delete('/:id/comment/:commentId', auth, async (req, res) => {
  try {
    const art = await Art.findById(req.params.id);
    if (!art) {
      return res.status(404).json({ error: 'Art not found' });
    }
    
    const comment = art.comments.id(req.params.commentId);
    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }
    
    if (comment.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Unauthorized' });
    }
    
    comment.deleteOne();
    await art.save();
    await art.populate('comments.user', 'username avatar');
    
    res.json({ comments: art.comments });
  } catch (error) {
    console.error('Delete comment error:', error);
    res.status(500).json({ error: 'Failed to delete comment' });
  }
});

// Remix art
router.post('/:id/remix', auth, async (req, res) => {
  try {
    const { newPrompt, style = 'default', title } = req.body;
    const originalArt = await Art.findById(req.params.id);
    
    let enhancedPrompt = newPrompt;
    if (style !== 'default' && styles[style]) {
      enhancedPrompt = `${newPrompt}, ${styles[style]}`;
    }
    
    const encodedPrompt = encodeURIComponent(enhancedPrompt);
    const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=512&height=512&nologo=true&enhance=true&seed=${Math.floor(Math.random() * 10000)}`;
    
    const remixArt = new Art({
      title: title || `Remix of ${originalArt.title || 'Untitled'}`,
      prompt: newPrompt,
      imageUrl,
      user: req.user._id,
      style,
      isRemix: true,
      originalArt: originalArt._id
    });
    
    await remixArt.save();
    await remixArt.populate('user', 'username avatar');
    
    res.json({ art: remixArt, imageUrl });
  } catch (error) {
    res.status(500).json({ error: 'Failed to remix art' });
  }
});

// Update art title
router.patch('/:id/title', auth, async (req, res) => {
  try {
    console.log('Update title request:', { artId: req.params.id, userId: req.user._id, title: req.body.title });
    const { title } = req.body;
    
    if (!title || !title.trim()) {
      return res.status(400).json({ error: 'Title is required' });
    }
    
    const art = await Art.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { title: title.trim() },
      { new: true }
    ).populate('user', 'username avatar');
    
    console.log('Updated art:', art);
    
    if (!art) {
      console.log('Art not found or unauthorized');
      return res.status(404).json({ error: 'Art not found or unauthorized' });
    }
    
    res.json(art);
  } catch (error) {
    console.error('Title update error:', error);
    res.status(500).json({ error: 'Failed to update title' });
  }
});

// Delete user's own art
router.delete('/:id', auth, async (req, res) => {
  try {
    console.log('Delete request:', { artId: req.params.id, userId: req.user._id });
    const art = await Art.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    console.log('Deleted art:', art);
    if (!art) {
      console.log('Art not found or unauthorized');
      return res.status(404).json({ error: 'Art not found or unauthorized' });
    }
    res.json({ message: 'Art deleted successfully' });
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ error: 'Failed to delete art' });
  }
});

// Get specific art by ID (must be last to avoid conflicts)
router.get('/:id', async (req, res) => {
  try {
    const art = await Art.findById(req.params.id)
      .populate('user', 'username avatar')
      .populate('comments.user', 'username avatar');
    if (!art) {
      return res.status(404).json({ error: 'Art not found' });
    }
    res.json(art);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch art' });
  }
});

// Admin: Delete any art
router.delete('/admin/:id', adminAuth, async (req, res) => {
  try {
    await Art.findByIdAndDelete(req.params.id);
    res.json({ message: 'Art deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete art' });
  }
});

module.exports = router;
